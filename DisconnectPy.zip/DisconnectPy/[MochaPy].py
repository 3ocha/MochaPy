import pyautogui
import pydirectinput
import time
import math
import webbrowser
import sys
import discord_webhook

from discord_webhook import DiscordWebhook, DiscordEmbed
from datetime import datetime
from sys import platform

# Even though the imports are used, PyCharm flags them as unused so I made these prints just to stop them flooding the errors.
print(sys)
print(discord_webhook)
print(math)

# Enter your info here:
# Enter your info here:
# Enter your info here:

privateServer = ""
webhookURL = ""
accountUnder13 = False

webhook = DiscordWebhook(url=webhookURL)

operatingSystem = ""
current_time = ""

if webhookURL != "":
    # Find operating system of user for the embed footer.

    if platform == "win32":
        operatingSystem = "Windows"
    elif platform == "linux" or "linux2":
        operatingSystem = "Linux"
    elif platform == "darwin":
        operatingSystem = "macOS"
    else:
        operatingSystem = "Unknown OS"

if not webbrowser:
    if webhookURL != "":
        print("Web browser is undetected.")

        embed = DiscordEmbed(title="FATAL ERROR: Web Browser Not Detected",
                             description="The macro has failed to detect a web browser. This could be because you do not have a default browser.",
                             color='77b255')
        embed.set_footer(text=current_time + " | " + operatingSystem)

        webhook.add_embed(embed)
        response = webhook.execute()
    exit()

    # Hasn't entered private server and account is over 13:
if privateServer == "" and accountUnder13 == False:
    webbrowser.open("google.com", new=1)
    time.sleep(3)
    pyautogui.hotkey('alt', 'f4')

    time.sleep(3)

    webbrowser.open("http://reconnect.mocha.lol")

    pydirectinput.keyDown("Ctrl")
    pydirectinput.press("L")
    pydirectinput.keyUp("Ctrl")

    pyautogui.write("https://roblox.com/games/11847142056?privateServerLinkCode=03181803371753385733422562039176")

    # Hasn't entered private server and account is under 13:
elif privateServer == "" and accountUnder13 == True:
    webbrowser.open("google.com", new=1)
    time.sleep(3)
    pyautogui.hotkey('alt', 'f4')

    time.sleep(3)

    webbrowser.open("https://roblox.com/games/11847142056/", new=1)
    time.sleep(5)

    pyautogui.click('playbutton.png')
    # Has entered a private server:
else:
    webbrowser.open("google.com", new=1)
    time.sleep(3)
    pyautogui.hotkey('alt', 'f4')

    time.sleep(3)

    webbrowser.open(privateServer, new=1)


pyautogui.click(960, 540)

time.sleep(20)

if pyautogui.pixelMatchesColor(350, 510, (251, 251, 255)) or pyautogui.pixelMatchesColor(350, 510, (115, 115, 117)):
    # Never use GoTo!
    if webhookURL != "":
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")

        pyautogui.write("Disconnected at {datetimeFormat}".format(datetimeFormat=current_time))

        embed = DiscordEmbed(title="Reconnected", description="The macro has successfully reconnected!", color='77b255',
                             footer=" | " + current_time)
        embed.set_footer(text=current_time + " | " + operatingSystem)

        webhook.add_embed(embed)
        response = webhook.execute()

    pydirectinput.click()

    pydirectinput.keyDown("w")
    time.sleep(4)
    pydirectinput.keyUp("w")

    pydirectinput.keyDown("a")
    time.sleep(7)
    pydirectinput.keyUp("a")

    pydirectinput.keyDown("d")
    time.sleep(9)
    pydirectinput.keyUp("d")

    Limiter1 = 0

    while True:
        pydirectinput.press("e")

        pydirectinput.keyDown("a")
        time.sleep(0.2)
        pydirectinput.keyUp("a")

        Limiter1 += 1

        if Limiter1 >= 28:
            break

    pydirectinput.press("/")

    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")

    pyautogui.write("Disconnected at {datetimeFormat}".format(datetimeFormat=current_time))

    pydirectinput.press("enter")
else:
    if webhookURL != "":
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")

        embed = DiscordEmbed(title="Reconnection Failed", description="The macro has not reconnected. This could be for many reasons but is most likely from your end.", color='ef4948')
        embed.set_footer(text=current_time + " | " + operatingSystem)

        webhook.add_embed(embed)
        response = webhook.execute()
        exit()
    else:
        exit()
